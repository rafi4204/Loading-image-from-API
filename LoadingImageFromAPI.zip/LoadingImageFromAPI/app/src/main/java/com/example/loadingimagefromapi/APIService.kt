package com.example.loadingimagefromapi



interface APIService {
    @GET("/json/glide.json")
    fun getInfo: Call<List<model>>

}